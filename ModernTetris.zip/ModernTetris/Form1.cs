﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ModernTetris
{
    public partial class MainForm : Form
    {
        private const int Rows = 20;
        private const int Columns = 10;
        private const int CellSize = 30;

        private int[,] grid = new int[Rows, Columns];
        private Timer timer;
        private Tetromino currentTetromino;
        private int score = 0;
        private Color[] colors = { Color.Transparent, Color.Cyan, Color.Yellow, Color.Purple, Color.Red, Color.Green, Color.Orange, Color.Blue };

        private Button restartButton;
        private Button pauseButton;
        private bool isPaused = false;

        public MainForm()
        {
            InitializeComponent();
            InitializeGame();

            restartButton = new Button
            {
                Text = "Restart",
                Location = new Point(Columns * CellSize + 20, 100),
                Size = new Size(100, 30),
                BackColor = Color.LightGray,
                Font = new Font("Arial", 10, FontStyle.Bold),
                TabStop = false // Предотвратява фокуса с Tab
            };
            restartButton.Click += RestartButton_Click;
            this.Controls.Add(restartButton);

            pauseButton = new Button
            {
                Text = "Pause",
                Location = new Point(Columns * CellSize + 20, 150),
                Size = new Size(100, 30),
                BackColor = Color.LightGray,
                Font = new Font("Arial", 10, FontStyle.Bold),
                TabStop = false // Предотвратява фокуса с Tab
            };
            pauseButton.Click += PauseButton_Click;
            this.Controls.Add(pauseButton);
        }

        private void InitializeGame()
        {
            this.Width = Columns * CellSize + 200; // Допълнително място за UI
            this.Height = Rows * CellSize + 39;
            this.Text = "Modern Tetris";
            this.DoubleBuffered = true;

            this.BackColor = Color.Black;

            timer = new Timer();
            timer.Interval = 300; // Скорост на падане
            timer.Tick += Timer_Tick;
            timer.Start();

            StartNewGame();
        }

        private void StartNewGame()
        {
            grid = new int[Rows, Columns];
            currentTetromino = Tetromino.GenerateRandom();
            score = 0;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            MoveTetrominoDown();
            Invalidate(); // Прерисува игралното поле
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Left)
            {
                MoveTetromino(-1);
            }
            else if (keyData == Keys.Right)
            {
                MoveTetromino(1);
            }
            else if (keyData == Keys.Down)
            {
                MoveTetrominoDown();
            }
            else if (keyData == Keys.Space)
            {
                RotateTetromino();
            }
            else if (keyData == Keys.Tab)
            {
                RotateTetromino360();
            }

            Invalidate(); // Прерисува игралното поле
            return true; // Указваме, че клавишът е обработен
        }

        private void RestartButton_Click(object sender, EventArgs e)
        {
            StartNewGame();
            timer.Start();
            isPaused = false;
            pauseButton.Text = "Pause";
            Invalidate();
        }

        private void PauseButton_Click(object sender, EventArgs e)
        {
            if (isPaused)
            {
                timer.Start();
                pauseButton.Text = "Pause";
            }
            else
            {
                timer.Stop();
                pauseButton.Text = "Resume";
            }
            isPaused = !isPaused;
        }

        private void MoveTetromino(int dx)
        {
            currentTetromino.X += dx;
            if (!IsValidPosition())
                currentTetromino.X -= dx;
        }

        private void MoveTetrominoDown()
        {
            currentTetromino.Y++;
            if (!IsValidPosition())
            {
                currentTetromino.Y--;
                PlaceTetromino();
                CheckForFullRows();
                currentTetromino = Tetromino.GenerateRandom();

                if (!IsValidPosition())
                {
                    timer.Stop();
                    MessageBox.Show($"Game Over! Score: {score}");
                    StartNewGame();
                }
            }
        }

        private void RotateTetromino()
        {
            currentTetromino.Rotate();
            if (!IsValidPosition())
                currentTetromino.RotateBack();
        }

        private void RotateTetromino360()
        {
            currentTetromino.Rotate();
            if (!IsValidPosition())
                currentTetromino.RotateBack();
        }

        private bool IsValidPosition()
        {
            for (int i = 0; i < currentTetromino.Shape.GetLength(0); i++)
            {
                for (int j = 0; j < currentTetromino.Shape.GetLength(1); j++)
                {
                    if (currentTetromino.Shape[i, j] == 1)
                    {
                        int x = currentTetromino.X + j;
                        int y = currentTetromino.Y + i;

                        if (x < 0 || x >= Columns || y < 0 || y >= Rows || (y >= 0 && grid[y, x] > 0))
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        private void PlaceTetromino()
        {
            for (int i = 0; i < currentTetromino.Shape.GetLength(0); i++)
            {
                for (int j = 0; j < currentTetromino.Shape.GetLength(1); j++)
                {
                    if (currentTetromino.Shape[i, j] == 1)
                    {
                        int x = currentTetromino.X + j;
                        int y = currentTetromino.Y + i;

                        if (y >= 0 && y < Rows && x >= 0 && x < Columns)
                            grid[y, x] = currentTetromino.ColorIndex;
                    }
                }
            }
        }

        private void CheckForFullRows()
        {
            for (int y = 0; y < Rows; y++)
            {
                bool isFull = true;

                for (int x = 0; x < Columns; x++)
                {
                    if (grid[y, x] == 0)
                    {
                        isFull = false;
                        break;
                    }
                }

                if (isFull)
                {
                    RemoveRow(y);
                    score += 100;
                }
            }
        }

        private void RemoveRow(int row)
        {
            for (int y = row; y > 0; y--)
            {
                for (int x = 0; x < Columns; x++)
                {
                    grid[y, x] = grid[y - 1, x];
                }
            }

            for (int x = 0; x < Columns; x++)
            {
                grid[0, x] = 0;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            Pen borderPen = new Pen(Color.White, 3);
            g.DrawRectangle(borderPen, 0, 0, Columns * CellSize, Rows * CellSize);

            for (int y = 0; y < Rows; y++)
            {
                for (int x = 0; x < Columns; x++)
                {
                    if (grid[y, x] > 0)
                    {
                        g.FillRectangle(new SolidBrush(colors[grid[y, x]]), x * CellSize, y * CellSize, CellSize, CellSize);
                        g.DrawRectangle(Pens.Black, x * CellSize, y * CellSize, CellSize, CellSize);
                    }
                }
            }

            if (currentTetromino != null)
            {
                for (int i = 0; i < currentTetromino.Shape.GetLength(0); i++)
                {
                    for (int j = 0; j < currentTetromino.Shape.GetLength(1); j++)
                    {
                        if (currentTetromino.Shape[i, j] == 1)
                        {
                            int x = (currentTetromino.X + j) * CellSize;
                            int y = (currentTetromino.Y + i) * CellSize;

                            g.FillRectangle(new SolidBrush(colors[currentTetromino.ColorIndex]), x, y, CellSize, CellSize);
                            g.DrawRectangle(Pens.Black, x, y, CellSize, CellSize);
                        }
                    }
                }
            }

            g.DrawString($"Score: {score}", new Font("Arial", 16), Brushes.White, Columns * CellSize + 10, 10);
        }
    }
}
