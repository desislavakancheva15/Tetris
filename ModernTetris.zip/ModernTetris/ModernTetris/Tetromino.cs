﻿using System;

namespace ModernTetris
{
    public class Tetromino
    {
        public int[,] Shape { get; private set; } // Формата на текущото тетромино
        public int X { get; set; } // Позиция по X
        public int Y { get; set; } // Позиция по Y
        public int ColorIndex { get; private set; } // Индекс за цвят

        public Tetromino(int[,] shape, int colorIndex)
        {
            Shape = shape;
            X = 3; // Начална позиция
            Y = 0;
            ColorIndex = colorIndex;
        }

        // Метод за завъртане на тетроминото
        public void Rotate()
        {
            int size = Shape.GetLength(0);
            int[,] rotated = new int[size, size];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    rotated[j, size - i - 1] = Shape[i, j];
                }
            }

            Shape = rotated;
        }

        // Метод за връщане на предишната ротация
        public void RotateBack()
        {
            int size = Shape.GetLength(0);
            int[,] rotated = new int[size, size];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    rotated[size - j - 1, i] = Shape[i, j];
                }
            }

            Shape = rotated;
        }

        // Метод за генериране на случайно тетромино
        public static Tetromino GenerateRandom()
        {
            int[][,] shapes = new int[][,]
            {
                new int[,] { { 1, 1, 1, 1 } }, // I
                new int[,] { { 1, 1 }, { 1, 1 } }, // O
                new int[,] { { 0, 1, 0 }, { 1, 1, 1 } }, // T
                new int[,] { { 1, 1, 0 }, { 0, 1, 1 } }, // Z
                new int[,] { { 0, 1, 1 }, { 1, 1, 0 } }, // S
                new int[,] { { 1, 1, 1 }, { 1, 0, 0 } }, // L
                new int[,] { { 1, 1, 1 }, { 0, 0, 1 } }  // J
            };

            Random rand = new Random();
            int index = rand.Next(shapes.Length);

            return new Tetromino(shapes[index], index + 1);
        }
    }
}
