﻿using System;
using System.Windows.Forms;

namespace ModernTetris
{
    static class Program
    {
        /// <summary>
        /// Главната входна точка за приложението.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm()); // Тук се стартира твоята главна форма
        }
    }
}
